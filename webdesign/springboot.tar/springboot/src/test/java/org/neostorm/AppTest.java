package org.neostorm;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertTrue;


/**
 * Unit test for simple App.
 */
public class AppTest 
{
    /**
     * Rigorous Test :-)
     */
	@DisplayName("Test shouldAnswerWithTrue()")
	@Test
    public void shouldAnswerWithTrue()
    {
		System.out.println("Hello World");
        assertTrue( true );
    }
}
